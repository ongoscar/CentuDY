﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Factories
{
    public class AddToCartFacto
    {
        public static DatabaseEntities db = new DatabaseEntities();

        public static Cart addToCart (int UserID, int MedicineID, int Quantity)
        {
            Cart cart = new Cart();
            cart.UserID = UserID;
            cart.MedicineID = MedicineID;
            cart.Quantity = Quantity;
            return cart;
        }
    }
}