﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Factories
{
    public class UserFactory
    {
        public static DatabaseEntities db = new DatabaseEntities();
        public static User UpdateUser(int id, String Name, String Gender, String phoneNumber, String Address)
        {
            User user = new User();
            user.UserID = id;
            user.Name = Name;
            user.Gender = Gender;
            user.PhoneNumber = phoneNumber;
            user.Address = Address;
            return user;
        }
    }
}