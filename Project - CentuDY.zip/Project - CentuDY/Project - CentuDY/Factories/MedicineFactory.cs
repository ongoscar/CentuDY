﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Factories
{

    public class MedicineFactory
    {
        public static DatabaseEntities db = new DatabaseEntities();

        public static Medicine CMedicine(String MedicineName, String Desc, int Stock, int Price)
        {
            Medicine medicine = new Medicine();
            medicine.Name = MedicineName;
            medicine.Description = Desc;
            medicine.Stock = Stock;
            medicine.Price = Price;
            return medicine;
        }

    }
}