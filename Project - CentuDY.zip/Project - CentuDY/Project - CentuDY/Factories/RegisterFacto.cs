﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Factories
{
    public class RegisterFacto
    {
        public static DatabaseEntities db = new DatabaseEntities();

        public static User registerUser (int roleID, string username, string password, string name, string gender, string phoneNumber, string address)
        {
            User user = new User
            {
                RoleID = roleID,
                Username = username,
                Password = password,
                Name = name,
                Gender = gender,
                PhoneNumber = phoneNumber,
                Address = address,
            };
            return user;
        }
    }
}