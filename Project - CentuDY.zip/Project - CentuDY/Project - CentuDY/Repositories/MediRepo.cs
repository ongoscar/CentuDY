﻿using Project___CentuDY.Factories;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Repositories
{
    public class MediRepo
    {
        public static DatabaseEntities db = new DatabaseEntities();

        public static List <Medicine> GetAllMedicine()
        {
            var query = (from x in db.Medicines select x);
            return query.ToList();
        }
        public static Medicine GetMedicine(int id)
        {
            var query = from x in db.Medicines where x.MedicineID == id select x;
            return query.FirstOrDefault();
        }
        public static List<Medicine> filter (String MedicineName)
        {
            var query = (from x in db.Medicines where x.Name.Contains(MedicineName) select x);
            return query.ToList();
        }

        public static bool UpdateMedicine(int id, String MedicineName, String Desc, int Stock, int Price)
        {
            var query = (from x in db.Medicines where x.MedicineID == id select x);
            Medicine medicine = GetMedicine(id);
            if (medicine == null) return false;
            medicine.Name = MedicineName;
            medicine.Description = Desc;
            medicine.Stock = Stock;
            medicine.Price = Price;
            db.SaveChanges();
            return true;
        }
        public static void InsertMedicine(String MedicineName, String Desc, int Stock, int Price)
        {
            Medicine medicine = MedicineFactory.CMedicine(MedicineName, Desc, Stock, Price);
            db.Medicines.Add(medicine);
            db.SaveChanges();
        }
        public static void DeleteMedicine(int medicineID)
        {
            Medicine medicine = GetMedicine(medicineID);
            db.Medicines.Remove(medicine);
            db.SaveChanges();
        }

    }
}