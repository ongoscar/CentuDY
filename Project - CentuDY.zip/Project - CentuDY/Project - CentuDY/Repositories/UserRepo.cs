﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Repositories
{
    public class UserRepo
    {
        public static DatabaseEntities db = new DatabaseEntities();
        public static bool UpdateUser(int id, String Name, String Gender, String phoneNumber, String Address)
        {
            var query = (from x in db.Users where x.UserID == id select x);
            User user = new User();
            if (user == null) return false;
            user.UserID = id;
            user.Name = Name;
            user.Gender = Gender;
            user.PhoneNumber = phoneNumber;
            user.Address = Address;
            db.SaveChanges();
            return true;
        }

        public static User GetUser(int id)
        {
            var query = (from x in db.Users where x.UserID == id select x);
            User user = (query).FirstOrDefault();
            return user;
        }

        public static void ChangePassword(int id, String nPass)
        {
            var query = (from x in db.Users where x.UserID == id select x);
            User user = (query).FirstOrDefault();
            user.Password = nPass;
            db.SaveChanges();
        }
    }
}