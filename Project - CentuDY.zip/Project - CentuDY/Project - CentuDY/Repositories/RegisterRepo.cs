﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Repositories
{
    public class RegisterRepo
    {
        public static DatabaseEntities db = new DatabaseEntities();

        public static void register(User user)
        {
            db.Users.Add(user);
            db.SaveChanges();
        }
    }
}