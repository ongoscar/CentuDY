﻿using Project___CentuDY.Factories;
using Project___CentuDY.Model;
using Project___CentuDY.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Handler
{
    public class MedicineHandler
    {

        public static void UpdateMedicine(int id, String MedicineName, String Desc, int Stock, int Price)
        {
            Medicine medicine = MedicineFactory.CMedicine(MedicineName, Desc, Stock, Price);
            MediRepo.UpdateMedicine(id, MedicineName, Desc, Stock, Price);
        }
        public static void InsertMedicine( String MedicineName, String Desc, int Stock, int Price)
        {
            Medicine medicine = MedicineFactory.CMedicine(MedicineName, Desc, Stock, Price);
            MediRepo.InsertMedicine(MedicineName, Desc, Stock, Price);
        }
        public static void DeleteMedicine(int MedicineId)
        {
            MediRepo.DeleteMedicine(MedicineId);
        }
        public static List<Medicine> filter(String MedicineName)
        {
            return MediRepo.filter(MedicineName);
        }
        public static List<Medicine> GetAllMedicine()
        {
            return MediRepo.GetAllMedicine();
        }
    }
}