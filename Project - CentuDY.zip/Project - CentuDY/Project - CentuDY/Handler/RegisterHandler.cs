﻿using Project___CentuDY.Factories;
using Project___CentuDY.Model;
using Project___CentuDY.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Handler
{
    public class RegisterHandler
    {
        public static void insertUser (string username, string password, string name, string gender, string phoneNumber, string address)
        {
            int roleID = 2;
            User user = RegisterFacto.registerUser(roleID, username, password, name, gender, phoneNumber, address);
            RegisterRepo.register(user);
        }

    }
}