﻿using Project___CentuDY.Factories;
using Project___CentuDY.Model;
using Project___CentuDY.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Handler
{
    public class UserHandler
    {
        public static void UpdateUser(int id, String Name, String Gender, String phoneNumber, String Address)
        {
            User user = UserFactory.UpdateUser(id, Name, Gender, phoneNumber, Address);
            UserRepo.UpdateUser(id, Name, Gender, phoneNumber, Address);
        }
        public static User GetUser(int id)
        {
            return UserRepo.GetUser(id);
        }

        public static void ChangePassword(int id, String nPass)
        {
            UserRepo.ChangePassword(id, nPass);
        }
    }
}