﻿using Project___CentuDY.Model;
using Project___CentuDY.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class Homepage : System.Web.UI.Page
    {
        private static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            {
                User user = (User)Session["User"];
                labelUsername.Text = user.Username;
                if (user.Role.RoleName == "Member")
                {
                    ButtonInsertMedicine.Visible = false;
                    ButtonViewUsers.Visible = false;
                    ButtonTransactionReport.Visible = false;
                }
                if (user.Role.RoleName == "Administrator")
                {
                    ButtonViewCart.Visible = false;
                    ButtonTransactionHistory.Visible = false;
                }
            }
        }
        protected void ButtonLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("user");
            Response.Cookies["User_Id"].Expires = DateTime.Now.AddMinutes(-30);
            Application["counter_user"] = (int)Application["counter_user"] - 1;
            Response.Redirect("Login.aspx");
        }

        protected void ButtonViewMedicine_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ViewMedicine.aspx");
        }

        protected void ButtonViewUsers_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewUser.aspx");
        }

        protected void ButtonViewProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewProfile.aspx");
        }

        protected void ButtonViewCart_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewCart.aspx");
        }

        protected void ButtonTransactionReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewTransactionReport.aspx");
        }

        protected void ButtonInsertMedicine_Click(object sender, EventArgs e)
        {
            Response.Redirect("InsertMedicine.aspx");
        }
    }
}