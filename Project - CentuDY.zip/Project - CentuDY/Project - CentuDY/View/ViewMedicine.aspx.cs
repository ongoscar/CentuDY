﻿using Project___CentuDY.Controllers;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class ViewMedicine : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["User"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                User user = (User)Session["User"];
                gvMedicine.DataSource = MedicineControll.GetAllMedicine();
                gvMedicine.DataBind();
                {
                    if (user.Role.RoleName == "Administrator")
                    {
                        
                        gvMedicine.Columns[0].Visible = false;
                    }
                    else if (user.Role.RoleName == "Member")
                    {
                        gvMedicine.Columns[1].Visible = false;
                        gvMedicine.Columns[2].Visible = false;
                        gvMedicine.Columns[3].Visible = false;
                    }
                }
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            gvMedicine.DataSource = MedicineControll.filter(txtsearch.Text);
            gvMedicine.DataBind();
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            var add = (sender as Button).CommandArgument;
            Response.Redirect("AddToCart.aspx?id" + add);
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            var add = (sender as Button).CommandArgument;
            Response.Redirect("UpdateMedicine.aspx?id" + add);
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            var add = (sender as Button).CommandArgument;
            Response.Redirect("InsertMedicine.aspx?id" + add);
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            var add = (sender as Button).CommandArgument;
            Medicine medicine = (from x in db.Medicines where x.MedicineID.Equals(add) select x).FirstOrDefault();
            db.Medicines.Remove(medicine);
            db.SaveChanges();
        }
    }
}