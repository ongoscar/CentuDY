﻿using Project___CentuDY.Controllers;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class UpdateProfile : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            int id = User.userID;
            if (!Page.IsPostBack)
            {
                if (Session["User"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                User user = (User)Session["User"];
                User user1 = UserControll.GetUser(id);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}