﻿using Project___CentuDY.Controllers;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class Register : System.Web.UI.Page
    {
        protected DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            String username = txtUsername.Text;
            String password = txtPassword.Text;
            String confirmPassword = txtConfirm.Text;
            String name = txtName.Text;
            String gender = txtGender.Text;
            String phoneNumber = txtPhone.Text;
            String address = txtAddress.Text;

            lblError.Text = RegisterControll.insertUser(username, password, confirmPassword, name, gender, phoneNumber, address);

            string error = RegisterControll.insertUser(username, password, confirmPassword, name, gender, phoneNumber, address);
            if (error.Equals("Success"))
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                lblError.Text = error;
            }
        }
    }
}