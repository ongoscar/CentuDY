﻿using Project___CentuDY.Controllers;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            User user = (User)Session["User"];
            lblError.Text = UserControll.ChangePassword(user.UserID, txtold.Text, txtpass.Text, txtconf.Text);
        }
    }
}