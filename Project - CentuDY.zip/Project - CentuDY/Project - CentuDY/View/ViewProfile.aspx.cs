﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class ViewProfile : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            User user = (User)Session["User"];
            lblUsername.Text = user.Username;
            lblName.Text = user.Name;
            lblGender.Text = user.Gender;
            lblPhone.Text = user.PhoneNumber;
            lblAddress.Text = user.Address;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("UpdateProfile.aspx");
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChangePassword.aspx");
        }
    }
}