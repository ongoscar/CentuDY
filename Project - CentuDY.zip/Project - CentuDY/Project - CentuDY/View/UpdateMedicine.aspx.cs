﻿using Project___CentuDY.Controllers;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class UpdateMedicine : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            User user = (User)Session["User"];
            if (user.Role.RoleName == "Member")
            {
                Response.Redirect("Homepage.aspx");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            String medicineId = Request.QueryString["MedicineID"];
            String MedicineName = txtName.Text;
            String MedicineDescription = txtDesc.Text;
            String MedicineStock = txtStock.Text;
            String MedicinePrice = txtPrice.Text;
            lblError.Text = MedicineControll.UpdateMedicine(medicineId, MedicineName, MedicineDescription, MedicineStock, MedicinePrice);
            db.SaveChanges();
        }
    }
}