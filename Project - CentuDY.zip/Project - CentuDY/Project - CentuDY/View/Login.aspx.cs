﻿using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project___CentuDY.View
{
    public partial class Login : System.Web.UI.Page
    {
        public static DatabaseEntities db = new DatabaseEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["user_id"] != null)
            {
                Response.Redirect("Homepage.aspx");
            }
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            String username = txtUsername.Text;
            String password = txtPassword.Text;
            var user = (from x in db.Users where x.Username == username && x.Password == password select x).FirstOrDefault();

            if (username.Equals("") || password.Equals(""))
            {
                lblError.Text = "Username or Password Must Be Filled";
                return;
            }

            if (user != null)
            {
                Session["user"] = user;
                if (rememberMe.Checked)
                {
                    HttpCookie cookie = new HttpCookie("user_id");
                    cookie.Value = user.UserID.ToString();
                    cookie.Expires = DateTime.Now.AddMinutes(30);
                    Response.Cookies.Add(cookie);
                }
                if (Application["counter_user"] == null)
                {
                    Application["counter_user"] = 1;
                }
                else
                {
                    Application["counter_user"] = (int)Application["counter_user"] + 1;
                }
                Response.Redirect("Homepage.aspx");
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}