﻿using Project___CentuDY.Handler;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Controllers
{
    public class UserControll
    {
        public static DatabaseEntities db = new DatabaseEntities();
        public static String UpdateUser(int id, String Name, String Gender, String phoneNumber, String Address)
        {
            {
                if (id == null)
                {
                    return "User Id cannot be empty";
                }
                else if(Name == null)
                {
                    return "User Name cannot be empty";
                }
                else if(Gender == null)
                {
                    return "User Gender Must be Choosen";
                }
                else if(!int.TryParse(phoneNumber, out int a))
                {
                    return "Phone Number must be numeric";
                }
                else if (phoneNumber == null)
                {
                    return "User Phone Number cannot be empty";
                }
                else if(!Address.StartsWith("Street"))
                {
                    return "Addres Must contain the word 'Street'";
                }
                else if (Address == null)
                {
                    return "Address Cannot be empty ";
                }
                UserHandler.UpdateUser(id, Name, Gender, phoneNumber, Address);
                return "success";
            }
        }
        public static String ChangePassword(int id, String oPass, String nPass, String cPass)
        {
            if (id == null)
            {
                return "User Id cannot be empty";
            }
            if (oPass == null)
            {
                return "Old password cannot be empty";
            }
            if (nPass == null)
            {
                return "New password cannot be empty";
            }
            if (cPass == null)
            {
                return "Confirm Password cannot be empty";
            }

            UserHandler.ChangePassword(id, nPass);
            return "success";
        }
        public static User GetUser(int id)
        {
            return UserHandler.GetUser(id);
        }
    }

}