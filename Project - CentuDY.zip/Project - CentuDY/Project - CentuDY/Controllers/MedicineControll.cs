﻿using Project___CentuDY.Handler;
using Project___CentuDY.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Controllers
{
    public class MedicineControll
    {
        
        public static String UpdateMedicine(String id, String MedicineName, String Desc, String Stock, String Price)
        {
            if (id == null)
            {
                return "Medicine Id cannot be empty";
            }
            else if(MedicineName == null)
            {
                return "Medicine Name cannot be empty";
            }
            else if(Desc == null || Desc.Length < 10)
            {
                return "Medicine Desc Must be longer than 10 characters and  cannot be empty";
            }
            else if(!int.TryParse(Stock, out int a))
            {
                return "Stock must be numeric";
            }
            else if(Stock == null)
            {
                return "Medicine Stock cannot be empty";
            }
            else if(!int.TryParse(Price, out int a))
            {
                return "Price must be numeric";
            }
            else if(Price == null)
            {
                return "Medicine Price cannot be empty";
            }
            MedicineHandler.UpdateMedicine(int.Parse(id), MedicineName, Desc, int.Parse(Stock), int.Parse(Price));
            return "success";
        }
        public static String InsertMedicine(String MedicineName, String Desc, String Stock, String Price)
        {
            if (MedicineName == null)
            {
                return "Medicine Name cannot be empty";
            }
            else if (Desc == null || Desc.Length < 10)
            {
                return "Medicine Desc Must be longer than 10 characters and  cannot be empty";
            }
            else if (!int.TryParse(Stock, out int a))
            {
                return "Stock must be numeric";
            }
            else if (Stock == null)
            {
                return "Medicine Stock cannot be empty";
            }
            else if (!int.TryParse(Price, out int a))
            {
                return "Price must be numeric";
            }
            else if (Price == null)
            {
                return "Medicine Price cannot be empty";
            }
            MedicineHandler.InsertMedicine(MedicineName, Desc, int.Parse(Stock), int.Parse(Price));
            return "success";
        }

        public static String DeleteMedicine(String Id)
        {
            int MedicineID = int.Parse(Id);
            if(MedicineID == null)
            {
                return "Medicine Id cannot be empty";
            }
            else
            {
                MedicineHandler.DeleteMedicine(MedicineID);
                HttpContext.Current.Response.Redirect("ViewMedicines.aspx");
                return "success";
            }
        }
        public static List<Medicine> filter(String MedicineName)
        {
            return MedicineHandler.filter(MedicineName);
        }

        public static List<Medicine> GetAllMedicine()
        {
            return MedicineHandler.GetAllMedicine();
        }
    }
}