﻿using Project___CentuDY.Handler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project___CentuDY.Controllers
{
    public class RegisterControll
    {
        public static string insertUser (string username, string password, string confirmPassword, string name, string gender, string phoneNumber, string address) 
        {
            if(username.Length <= 2 || username == null) 
            {
                return "Username Minimal length is 3 characters, must be unique, and Cannot be empty";
            }

            else if(password.Length <=7 || username == null )
            {
                return "Password Minimal length is 8 characters and Cannot be empty";
            }

            else if(confirmPassword != password || confirmPassword == null)
            {
                return "Must be the same as the inputted password and Cannot be empty";
            }

            else if(name == null)
            {
                return "Name Cannot be empty";
            }

            else if(!int.TryParse(phoneNumber, out int a))
            {
                return "Phone Number must be numeric";
            }

            else if (phoneNumber == null)
            {
                return "Phone Number Cannot be empty ";
            }

            else if(gender == null)
            {
                return "Gender Must be chosen";
            }

            else if(!address.StartsWith("Street"))
            {
                return "Addres Must contain the word 'Street'";
            }
            else if (address == null)
            {
                return "Address Cannot be empty ";
            }

            else
            {
                RegisterHandler.insertUser( username, password, name, gender, phoneNumber, address);
                return "Success";
            }
        }
    }
}